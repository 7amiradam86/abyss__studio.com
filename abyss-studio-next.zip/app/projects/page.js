'use client';
import { useMemo, useState, useEffect } from 'react';
import Image from 'next/image';
import { useSearchParams } from 'next/navigation';
import { PROJECTS, TYPE_OPTIONS, STATUS_OPTIONS, LOCATIONS } from '../../lib/data';
import { ChevronRight, ChevronLeft, X, MapPin, Plus, Check } from 'lucide-react';

function Tag({children}){ return <span className="tag">{children}</span> }

function SectionTitle({kicker, title, aside}){
  return (
    <div className="mb-8 flex items-end justify-between gap-4">
      <div>
        {kicker && <div className="text-[10px] uppercase tracking-[0.2em] mb-2">{kicker}</div>}
        <h2 className="text-2xl md:text-3xl font-medium">{title}</h2>
      </div>
      {aside}
    </div>
  );
}

function ProjectModal({ project, onClose, onAddSelection }){
  const [index, setIndex] = useState(0);
  useEffect(()=> setIndex(0), [project]);
  if(!project) return null;
  const next = () => setIndex(i => (i+1) % project.images.length);
  const prev = () => setIndex(i => (i-1+project.images.length) % project.images.length);
  return (
    <div className="fixed inset-0 z-50 bg-white/95 overflow-y-auto">
      <div className="container py-6 md:py-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h3 className="text-xl md:text-2xl font-medium">{project.title}</h3>
            <Tag>{project.type}</Tag>
            <Tag>{project.status}</Tag>
          </div>
          <div className="flex items-center gap-2">
            <button className="btn" onClick={()=> onAddSelection(project)}><Plus className="h-4 w-4"/> My selection</button>
            <button className="btn" onClick={onClose}><X className="h-4 w-4"/> Close</button>
          </div>
        </div>
        <div className="mt-4 rounded-2xl overflow-hidden border">
          <div className="relative aspect-[16/9] bg-black">
            {/* Use plain img to avoid layout shift in modal */}
            <img src={project.images[index]} alt="" className="h-full w-full object-cover" />
            <button className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/80 border" onClick={prev}><ChevronLeft className="h-5 w-5"/></button>
            <button className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/80 border" onClick={next}><ChevronRight className="h-5 w-5"/></button>
          </div>
        </div>
        <div className="mt-6 grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-4">
            <p className="leading-relaxed text-[15px]">An exploration of light, shadow, and porosity shaped by context. The project orchestrates a dialogue between interior and exterior through layered skins and calibrated apertures.</p>
            <p className="leading-relaxed text-[15px]">Material clarity and daylight choreography define the spatial narrative, while systems are tuned for climate and program.</p>
          </div>
          <aside className="space-y-3 text-sm">
            <Meta label="Status" value={project.status} />
            <Meta label="Dates" value={project.dates} />
            <Meta label="Client" value={project.client} />
            <Meta label="Type of assignment" value={project.mission} />
            <Meta label="Program" value={project.program} />
            <Meta label="Surface" value={project.surface} />
            <Meta label="Location" value={<span className="inline-flex items-center gap-1"><MapPin className="h-4 w-4"/>{project.location}</span>} />
            <Meta label="Team" value={<ul className="list-disc list-inside">{project.team.map(t=> <li key={t}>{t}</li>)}</ul>} />
          </aside>
        </div>
      </div>
    </div>
  );
}

function Meta({ label, value }){
  return (
    <div>
      <div className="text-[10px] uppercase tracking-[0.2em] text-gray-500">{label}</div>
      <div className="mt-1">{value}</div>
    </div>
  );
}

function MultiSelect({ label, options, values, onChange }){
  const toggle = (opt) => {
    if(values.includes(opt)) onChange(values.filter(v=> v!==opt));
    else onChange([...values, opt]);
  };
  return (
    <div className="relative">
      <details className="group">
        <summary className="list-none select-none inline-flex items-center gap-2 btn cursor-pointer">
          {label} ({values.length})
          <svg viewBox="0 0 20 20" className="h-3 w-3" aria-hidden="true"><path fill="currentColor" fillRule="evenodd" d="M5.23 7.21a.75.75 0 0 1 1.06.02L10 10.06l3.71-2.83a.75.75 0 1 1 .92 1.18l-4.25 3.25a.75.75 0 0 1-.92 0L5.25 8.41a.75.75 0 0 1-.02-1.2z" clipRule="evenodd"/></svg>
        </summary>
        <div className="absolute left-0 mt-2 w-56 rounded-xl border bg-white shadow-lg p-2 z-20">
          {options.map((opt)=> (
            <label key={opt} className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-gray-50">
              <input type="checkbox" checked={values.includes(opt)} onChange={()=> toggle(opt)} />
              <span className="text-sm">{opt}</span>
            </label>
          ))}
        </div>
      </details>
    </div>
  );
}

export default function ProjectsPage(){
  const sp = useSearchParams();
  const initialQuery = sp.get('query') || '';
  const [view, setView] = useState('images'); // images | list
  const [showTitles, setShowTitles] = useState(true);
  const [types, setTypes] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [region, setRegion] = useState('World');
  const [query, setQuery] = useState(initialQuery);
  const [project, setProject] = useState(null);
  const [selection, setSelection] = useState([]);

  useEffect(()=> { setQuery(initialQuery); }, [initialQuery]);
  const addSel = (p) => setSelection((xs)=> xs.some(s=> s.id===p.id) ? xs : [...xs, p]);
  const removeSel = (p) => setSelection((xs)=> xs.filter(s=> s.id!==p.id));

  const filtered = useMemo(() => {
    return PROJECTS.filter(p => {
      const q = query.trim().toLowerCase();
      const qok = !q || [p.title, p.type, p.location, p.program].join(' ').toLowerCase().includes(q);
      const tok = types.length === 0 || types.includes(p.type);
      const sok = statuses.length === 0 || statuses.includes(p.status);
      const rok = region === 'World' || p.location.toLowerCase().includes(region.toLowerCase());
      return qok && tok && sok && rok;
    });
  }, [query, types, statuses, region]);

  return (
    <main className="container py-10">
      <SectionTitle kicker="Archive" title="Projects" aside={
        <div className="flex items-center gap-2">
          <button className={`btn ${view==='images'?'bg-black text-white':''}`} onClick={()=> setView('images')}>Images</button>
          <button className={`btn ${view==='list'?'bg-black text-white':''}`} onClick={()=> setView('list')}>List</button>
          <button className="btn" onClick={()=> setShowTitles(s=>!s)}>{showTitles? 'Hide titles':'Show titles'}</button>
        </div>
      }/>
      <div className="grid md:grid-cols-4 gap-4 items-end">
        <div className="md:col-span-2">
          <input className="input w-full" placeholder="Search projects" value={query} onChange={(e)=> setQuery(e.target.value)} />
        </div>
        <div className="flex flex-wrap gap-2">
          <select className="input" value={region} onChange={(e)=> setRegion(e.target.value)}>
            {LOCATIONS.map(r=> <option key={r} value={r}>{r}</option>)}
          </select>
          <MultiSelect label="Type" options={TYPE_OPTIONS} values={types} onChange={setTypes} />
          <MultiSelect label="Status" options={STATUS_OPTIONS} values={statuses} onChange={setStatuses} />
        </div>
      </div>

      {view==='images' ? (
        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map(p => (
            <article key={p.id} className="card group">
              <div className="relative aspect-[4/3] bg-gray-50">
                <Image src={p.images[0]} alt="" width={1600} height={1200} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]" />
                <button title="Add to selection" onClick={()=> addSel(p)} className="absolute right-2 top-2 rounded-full border bg-white/80 p-2">
                  {selection.some(s=> s.id===p.id) ? <Check className="h-4 w-4"/> : <Plus className="h-4 w-4"/>}
                </button>
              </div>
              <div className="p-4">
                {showTitles && <h3 className="text-lg leading-tight">{p.title}</h3>}
                <div className="text-sm text-gray-500">{p.location}</div>
                <div className="mt-2 flex flex-wrap gap-2 text-[11px] uppercase tracking-widest text-gray-500">
                  <Tag>{p.type}</Tag><Tag>{p.status}</Tag><Tag>{p.dates}</Tag>
                </div>
                <div className="mt-3">
                  <button className="btn" onClick={()=> setProject(p)}>View project</button>
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="mt-6 divide-y border rounded-2xl overflow-hidden">
          {filtered.map(p => (
            <div key={p.id} className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-4">
              <div className="flex items-center gap-4">
                <div className="h-14 w-20 overflow-hidden rounded-lg bg-gray-100">
                  <img src={p.images[0]} alt="" className="h-full w-full object-cover"/>
                </div>
                <div>
                  <div className="text-sm text-gray-500">{p.type} · {p.status}</div>
                  <button className="text-base md:text-lg hover:underline text-left" onClick={()=> setProject(p)}>{p.title}</button>
                  <div className="text-sm text-gray-500">{p.location}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button className="btn" onClick={()=> addSel(p)}>{selection.some(s=> s.id===p.id) ? 'Added' : 'My selection'}</button>
                <button className="btn" onClick={()=> setProject(p)}>Open</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Selection tray */}
      {selection.length>0 && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40">
          <div className="rounded-2xl border bg-white shadow-xl w-[90vw] md:w-[720px]">
            <div className="flex items-center justify-between p-3">
              <div className="text-sm">My selection · {selection.length} project(s)</div>
              <div className="flex items-center gap-2">
                <button className="btn" onClick={()=> navigator.clipboard.writeText(selection.map(i=> i.title).join(', '))}>Copy list</button>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-3">
              {selection.map(p=> (
                <div key={p.id} className="relative group">
                  <img src={p.images[0]} alt="" className="h-24 w-full object-cover rounded-lg border"/>
                  <button onClick={()=> removeSel(p)} className="absolute right-1 top-1 p-1 rounded-full bg-white/90 border"><X className="h-3 w-3"/></button>
                  <div className="mt-1 text-[11px] leading-tight">{p.title}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <ProjectModal project={project} onClose={()=> setProject(null)} onAddSelection={addSel} />
    </main>
  );
}
