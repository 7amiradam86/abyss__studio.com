'use client';
export default function Careers(){
  const OPEN_ROLES = [
    { id: 'r1', role: 'Architect (3–6 yrs)', office: 'Paris', date: 'Aug 2025', cat: 'Architecture' },
    { id: 'r2', role: 'BIM Coordinator', office: 'Shanghai', date: 'Aug 2025', cat: 'Technology' },
    { id: 'r3', role: 'Interior Architect', office: 'Paris', date: 'Jul 2025', cat: 'Interiors' },
  ];
  const onSubmit = (e)=> { e.preventDefault(); alert('Application submitted.'); };
  return (
    <main className="container py-12">
      <div className="mb-8">
        <div className="text-[10px] uppercase tracking-[0.2em] mb-2">Join us</div>
        <h2 className="text-2xl md:text-3xl font-medium">Open positions</h2>
      </div>
      <div className="rounded-2xl border overflow-hidden">
        {OPEN_ROLES.map((r)=> (
          <div key={r.id} className="grid md:grid-cols-5 gap-2 p-4 border-b last:border-b-0">
            <div className="md:col-span-2">{r.role}</div>
            <div>{r.office}</div>
            <div className="text-gray-500">{r.cat}</div>
            <div className="flex items-center justify-end">{r.date}</div>
          </div>
        ))}
      </div>
      <div className="mt-8">
        <div className="mb-4">
          <div className="text-[10px] uppercase tracking-[0.2em] mb-2">Apply</div>
          <h3 className="text-xl font-medium">Application form</h3>
        </div>
        <form onSubmit={onSubmit} className="space-y-3 max-w-2xl">
          <input className="input w-full" placeholder="Full name" required />
          <input className="input w-full" placeholder="Email" type="email" required />
          <input className="input w-full" placeholder="Role you're applying for" required />
          <textarea className="input w-full h-32" placeholder="Short introduction" required />
          <button className="btn" type="submit">Submit</button>
        </form>
      </div>
    </main>
  );
}
