export default function Author(){
  return (
    <main className="container py-12">
      <div className="mb-8">
        <div className="text-[10px] uppercase tracking-[0.2em] mb-2">Author</div>
        <h2 className="text-2xl md:text-3xl font-medium">Abyss Studio — Biography</h2>
      </div>
      <div className="prose prose-neutral max-w-none">
        <p>
          Abyss Studio pursues singular answers to specific places. Each project
          is conceived as a precise instrument for light, climate, and program—
          a refusal of generic style in favor of context and narrative.
        </p>
        <p>
          The practice works across architecture, urbanism, interiors, and exhibitions,
          assembling ad‑hoc teams of engineers, fabricators, and artists. Research and
          scenography are integral to design, resulting in buildings that perform
          technically while speaking poetically.
        </p>
        <h3>Selected distinctions</h3>
        <ul>
          <li>2025 — Global Design Award, Tower category</li>
          <li>2024 — Urban Light Prize, Public space</li>
          <li>2023 — Arch Medium, Exhibition scenography</li>
        </ul>
      </div>
    </main>
  );
}
