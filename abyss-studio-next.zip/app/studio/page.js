export default function Studio(){
  return (
    <main className="container py-12">
      <div className="mb-8">
        <div className="text-[10px] uppercase tracking-[0.2em] mb-2">The Ateliers</div>
        <h2 className="text-2xl md:text-3xl font-medium">Paris & Shanghai</h2>
      </div>
      <div className="grid md:grid-cols-2 gap-10">
        <div className="card">
          <div className="p-6 border-b"><div className="text-lg font-medium">Paris</div></div>
          <div className="p-6 text-sm space-y-3">
            <p>130-person, multidisciplinary team across architecture, urbanism, interior design, landscape, and graphic/product design.</p>
            <p>Books and exhibitions produced in-house extend research beyond construction sites.</p>
            <p>Contacts: 12 Rue des Horizons, 75003 Paris · +33 1 23 45 67 89</p>
          </div>
        </div>
        <div className="card">
          <div className="p-6 border-b"><div className="text-lg font-medium">Shanghai</div></div>
          <div className="p-6 text-sm space-y-3">
            <p>China office focusing on cultural and mixed-use programs, with bilingual teams and local partners.</p>
            <p>Projects include museums, towers, and temporary pavilions with scenographic emphasis.</p>
            <p>Contacts: 88 Huangpu Rd, Shanghai · +86 21 5555 6666</p>
          </div>
        </div>
      </div>
    </main>
  );
}
