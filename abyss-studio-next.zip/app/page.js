import Image from 'next/image';
import Link from 'next/link';
import { NEWS } from '../lib/data';

function Tag({children}){ return <span className="tag">{children}</span> }

export default function HomePage(){
  return (
    <main className="container py-10">
      <div className="mb-8 flex items-end justify-between gap-4">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] mb-2">Highlights</div>
          <h2 className="text-2xl md:text-3xl font-medium">Editorial feed</h2>
        </div>
        <Link href="/news" className="text-sm hover:underline">View news</Link>
      </div>
      <div className="grid md:grid-cols-3 gap-6">
        {NEWS.map(n => (
          <article key={n.id} className="group">
            <div className="aspect-[4/3] overflow-hidden rounded-2xl border bg-gray-50">
              <Image src={n.img} alt="" width={1600} height={1200} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]" />
            </div>
            <div className="mt-3 flex items-center gap-2 text-[11px] uppercase tracking-widest text-gray-500">
              <Tag>{n.tag}</Tag><span>·</span><span>{n.date}</span>
            </div>
            <h3 className="text-lg md:text-xl mt-1">{n.title}</h3>
            <div className="text-sm text-gray-500">{n.location}</div>
            <div className="text-xs text-gray-500 mt-1">{n.credit}</div>
          </article>
        ))}
      </div>
    </main>
  );
}
