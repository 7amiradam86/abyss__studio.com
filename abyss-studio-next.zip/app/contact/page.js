'use client';
export default function Contact(){
  const onSubmit = (e)=> { e.preventDefault(); alert('Message sent. Thank you!'); };
  return (
    <main className="container py-12">
      <div className="mb-8">
        <div className="text-[10px] uppercase tracking-[0.2em] mb-2">Contacts</div>
        <h2 className="text-2xl md:text-3xl font-medium">Get in touch</h2>
      </div>
      <div className="grid gap-6">
        <div className="text-sm space-y-2">
          <div><span className="font-medium">Paris</span> — 12 Rue des Horizons, 75003 · +33 1 23 45 67 89</div>
          <div><span className="font-medium">Shanghai</span> — 88 Huangpu Rd · +86 21 5555 6666</div>
          <div className="text-gray-500">press@abyss.studio · newbusiness@abyss.studio</div>
        </div>
        <form onSubmit={onSubmit} className="space-y-3 max-w-md">
          <input className="input w-full" placeholder="Name" required />
          <input className="input w-full" placeholder="Email" type="email" required />
          <textarea className="input w-full h-40" placeholder="Your message" required />
          <button className="btn" type="submit">Send</button>
        </form>
      </div>
    </main>
  );
}
