'use client';
import Link from 'next/link';
import { useState } from 'react';
import { Search } from 'lucide-react';

export default function Header(){
  const [q, setQ] = useState('');
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b">
      <div className="container py-3 flex items-center justify-between">
        <Link href="/" className="font-medium tracking-wide text-lg no-underline">Abyss Studio</Link>
        <nav className="hidden md:flex items-center gap-6 text-sm">
          <Link href="/author" className="hover:underline">Author</Link>
          <Link href="/studio" className="hover:underline">The Ateliers</Link>
          <Link href="/projects" className="hover:underline">Projects</Link>
          <Link href="/contact" className="hover:underline">Contacts</Link>
          <Link href="/careers" className="hover:underline">Join us</Link>
        </nav>
        <div className="flex items-center gap-2">
          <div className="relative hidden sm:block">
            <input className="input pl-8 w-48" placeholder="Search"
              value={q} onChange={(e)=> setQ(e.target.value)}
              onKeyDown={(e)=> { if(e.key==='Enter') window.location.href=`/projects?query=${encodeURIComponent(q)}`; }}
            />
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4"/>
          </div>
          <div className="text-xs uppercase tracking-widest">En</div>
        </div>
      </div>
    </header>
  );
}
