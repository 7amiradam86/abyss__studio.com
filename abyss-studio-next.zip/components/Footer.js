export default function Footer(){
  return (
    <footer className="border-t mt-24">
      <div className="container py-10 text-sm flex flex-col md:flex-row gap-6 md:gap-10 md:items-end md:justify-between">
        <div>
          <div className="font-medium">Abyss Studio</div>
          <div className="text-gray-500">© {new Date().getFullYear()} — All rights reserved.</div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-gray-500">
          <a className="hover:underline" href="https://instagram.com" target="_blank">Instagram</a>
          <a className="hover:underline" href="https://linkedin.com" target="_blank">LinkedIn</a>
          <a className="hover:underline" href="https://youtube.com" target="_blank">YouTube</a>
          <a className="hover:underline" href="https://twitter.com" target="_blank">X/Twitter</a>
        </div>
      </div>
    </footer>
  );
}
